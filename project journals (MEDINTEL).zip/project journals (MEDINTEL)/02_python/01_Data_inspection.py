import pandas as pd

# Load the MEDINTEL development dataset
df = pd.read_csv("01_data/MEDINTEL_development_dataset_650_rows.csv")
# Display first 5 rows
print(df.head())

# Display number of rows and columns
print("\nDataset Shape:")
print(df.shape)

# Display column names
print("\nColumn Names:")
print(df.columns)

# Display data types
print("\nData Types:")
print(df.dtypes)

# Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Check duplicate rows
print("\nDuplicate Rows:")
print(df.duplicated().sum())
