import pandas as pd

# Load the MEDINTEL development dataset
df = pd.read_csv("01_data/MEDINTEL_development_dataset_650_rows.csv")

# Convert date columns to proper date format
df["Date of Sale"] = pd.to_datetime(df["Date of Sale"])
df["Expiry Date"] = pd.to_datetime(df["Expiry Date"])

# Check data types after conversion
print("Data Types After Cleaning:")
print(df.dtypes)

# Check for invalid numeric values
print("\nNegative Quantity Sold:")
print((df["Quantity Sold"] < 0).sum())

print("\nNegative Selling Price:")
print((df["Selling Price"] < 0).sum())

print("\nNegative Current Stock:")
print((df["Current Stock"] < 0).sum())

# Display cleaned data
print("\nFirst 5 Rows After Cleaning:")
print(df.head())