import pandas as pd

# Load the MEDINTEL development dataset
df = pd.read_csv("01_data/MEDINTEL_development_dataset_650_rows.csv")

# Total quantity sold for each medicine
medicine_sales = df.groupby("Medicine Name")["Quantity Sold"].sum()

# Sort medicines from highest to lowest sales
medicine_sales = medicine_sales.sort_values(ascending=False)

print("Total Quantity Sold by Medicine:")
print(medicine_sales)

# Top 10 fast-moving medicines
print("\nTop 10 Fast-Moving Medicines:")
print(medicine_sales.head(10))

# Total quantity sold by category
category_sales = df.groupby("Category")["Quantity Sold"].sum()

# Sort categories from highest to lowest sales
category_sales = category_sales.sort_values(ascending=False)

print("\nTotal Quantity Sold by Category:")
print(category_sales)

# Convert Date of Sale to datetime
df["Date of Sale"] = pd.to_datetime(df["Date of Sale"])

# Create Month column
df["Month"] = df["Date of Sale"].dt.to_period("M")

# Calculate monthly quantity sold
monthly_sales = df.groupby("Month")["Quantity Sold"].sum()

print("\nMonthly Quantity Sold:")
print(monthly_sales)

# Total sales revenue
total_revenue = df["Total Sale Value"].sum()

print("\nTotal Sales Revenue:")
print(total_revenue)

# Monthly sales revenue
monthly_revenue = df.groupby("Month")["Total Sale Value"].sum()

print("\nMonthly Sales Revenue:")
print(monthly_revenue)


# Average current stock by medicine
stock_analysis = df.groupby("Medicine Name")["Current Stock"].mean()

# Sort from lowest to highest stock
stock_analysis = stock_analysis.sort_values()

print("\nMedicines with Lowest Average Stock:")
print(stock_analysis.head(10))


# Calculate total quantity sold and average stock by medicine
inventory_analysis = df.groupby("Medicine Name").agg(
    Total_Sold=("Quantity Sold", "sum"),
    Average_Stock=("Current Stock", "mean")
)

# Estimate average daily demand
inventory_analysis["Average_Daily_Demand"] = (
    inventory_analysis["Total_Sold"] / 180
)

# Estimate how many days the current average stock may last
inventory_analysis["Estimated_Stock_Cover_Days"] = (
    inventory_analysis["Average_Stock"] /
    inventory_analysis["Average_Daily_Demand"]
)

# Sort medicines by lowest stock cover
inventory_analysis = inventory_analysis.sort_values(
    "Estimated_Stock_Cover_Days"
)

print("\nMedicines with Lowest Estimated Stock Cover:")
print(inventory_analysis.head(10))