import sqlite3
import pandas as pd

df = pd.read_csv("01_data/MEDINTEL_development_dataset_650_rows.csv")

connection = sqlite3.connect("medintel.db")

df.to_sql("pharmacy_sales", connection, if_exists="replace", index=False)

print("Dataset successfully imported into SQL table!")

connection.close()