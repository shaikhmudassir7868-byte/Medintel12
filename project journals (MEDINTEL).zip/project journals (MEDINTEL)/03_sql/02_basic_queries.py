import sqlite3

# Connect to MEDINTEL database
connection = sqlite3.connect("medintel.db")

cursor = connection.cursor()

# Display first 10 records
query = """
SELECT *
FROM pharmacy_sales
LIMIT 10;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("First 10 Records:")
for row in rows:
    print(row)


# Total quantity sold by medicine
query = """
SELECT
    "Medicine Name",
    SUM("Quantity Sold") AS Total_Quantity_Sold
FROM pharmacy_sales
GROUP BY "Medicine Name"
ORDER BY Total_Quantity_Sold DESC
LIMIT 10;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("\nTop 10 Fast-Moving Medicines using SQL:")
for row in rows:
    print(row)


# Total quantity sold by category
query = """
SELECT
    Category,
    SUM("Quantity Sold") AS Total_Quantity_Sold
FROM pharmacy_sales
GROUP BY Category
ORDER BY Total_Quantity_Sold DESC;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("\nTotal Quantity Sold by Category using SQL:")
for row in rows:
    print(row)


# Monthly Sales Analysis
query = """
SELECT
    substr("Date of Sale", 1, 7) AS Month,
    SUM("Quantity Sold") AS Total_Quantity_Sold,
    SUM("Total Sale Value") AS Total_Revenue
FROM pharmacy_sales
GROUP BY Month
ORDER BY Month;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("\nMonthly Sales Analysis using SQL:")
for row in rows:
    print(row)


# Low Stock Medicines
query = """
SELECT
    "Medicine Name",
    ROUND(AVG("Current Stock"), 2) AS Average_Stock
FROM pharmacy_sales
GROUP BY "Medicine Name"
ORDER BY Average_Stock ASC
LIMIT 10;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("\nLowest Average Stock Medicines using SQL:")
for row in rows:
    print(row)


# Medicine-wise Sales and Average Stock
query = """
SELECT
    "Medicine Name",
    SUM("Quantity Sold") AS Total_Quantity_Sold,
    ROUND(AVG("Current Stock"), 2) AS Average_Stock
FROM pharmacy_sales
GROUP BY "Medicine Name"
ORDER BY Total_Quantity_Sold DESC
LIMIT 10;
"""

cursor.execute(query)

rows = cursor.fetchall()

print("\nMedicine-wise Sales and Average Stock using SQL:")
for row in rows:
    print(row)


# Close database connection
connection.close()