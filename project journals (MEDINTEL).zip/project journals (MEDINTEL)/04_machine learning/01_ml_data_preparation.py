import pandas as pd
import sqlite3
import os

# ==============================
# MEDINTEL DATABASE PATH
# ==============================

BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATABASE = os.path.join(
    BASE_DIR,
    "medintel.db"
)

print("\nMEDINTEL DATABASE:")
print(DATABASE)

# Check database exists
if not os.path.exists(DATABASE):
    raise FileNotFoundError(
        f"\nMEDINTEL database not found:\n{DATABASE}"
    )

# ==============================
# CONNECT TO DATABASE
# ==============================

connection = sqlite3.connect(DATABASE)

# Check available tables
tables = pd.read_sql_query(
    "SELECT name FROM sqlite_master WHERE type='table'",
    connection
)

print("\nAVAILABLE TABLES:")
print(tables)

# Check pharmacy_sales table
if "pharmacy_sales" not in tables["name"].values:

    connection.close()

    raise ValueError(
        "\npharmacy_sales table not found.\n"
        "Please upload the pharmacy CSV through the MEDINTEL website first."
    )

# ==============================
# LOAD PHARMACY DATA
# ==============================

df = pd.read_sql_query(
    "SELECT * FROM pharmacy_sales",
    connection
)

connection.close()

print("\nMEDINTEL ML DATA LOADED FROM SQL")

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Columns:")
print(df.columns.tolist())

# ==============================
# CHECK DATA
# ==============================

if df.empty:
    raise ValueError(
        "No pharmacy data found in SQL database."
    )

# ==============================
# DATE PROCESSING
# ==============================

df["Date of Sale"] = pd.to_datetime(
    df["Date of Sale"],
    errors="coerce"
)

df = df.dropna(
    subset=["Date of Sale"]
)

# ==============================
# CREATE DATE FEATURES
# ==============================

df["Month"] = df["Date of Sale"].dt.month

df["Day"] = df["Date of Sale"].dt.day

df["Day_of_Week"] = (
    df["Date of Sale"].dt.dayofweek
)

# ==============================
# SORT DATA
# ==============================

df = df.sort_values(
    ["Medicine Name", "Date of Sale"]
)

# ==============================
# PREVIOUS DEMAND
# ==============================

df["Previous_Demand"] = (
    df.groupby("Medicine Name")["Quantity Sold"]
    .shift(1)
)

# ==============================
# ROLLING AVERAGE DEMAND
# ==============================

df["Rolling_Average_Demand"] = (
    df.groupby("Medicine Name")["Quantity Sold"]
    .transform(
        lambda x:
        x.shift(1).rolling(3).mean()
    )
)

# ==============================
# REMOVE MISSING ML VALUES
# ==============================

df = df.dropna(
    subset=[
        "Previous_Demand",
        "Rolling_Average_Demand"
    ]
)

# ==============================
# DISPLAY PREPARED DATA
# ==============================

print("\nPREPARED ML DATA:")

print(
    df[
        [
            "Medicine Name",
            "Date of Sale",
            "Quantity Sold",
            "Previous_Demand",
            "Rolling_Average_Demand"
        ]
    ].head(10)
)

# ==============================
# ML FEATURES
# ==============================

features = [
    "Selling Price",
    "Current Stock",
    "Month",
    "Day",
    "Day_of_Week",
    "Previous_Demand",
    "Rolling_Average_Demand"
]

X = df[features]

y = df["Quantity Sold"]

# ==============================
# DISPLAY SHAPES
# ==============================

print("\nINPUT FEATURES SHAPE:")
print(X.shape)

print("\nTARGET SHAPE:")
print(y.shape)

print("\nML FEATURES:")
print(features)

print(
    "\nML DATA PREPARATION COMPLETED SUCCESSFULLY!"
)