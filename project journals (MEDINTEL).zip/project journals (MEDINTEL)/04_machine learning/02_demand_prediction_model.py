import pandas as pd
import sqlite3
import os

from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# =========================================================
# MEDINTEL PROJECT PATH
# =========================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATABASE = os.path.join(
    BASE_DIR,
    "medintel.db"
)

OUTPUT_FILE = os.path.join(
    BASE_DIR,
    "01_data",
    "MEDINTEL_ML_Decision_Support.csv"
)


# =========================================================
# CHECK DATABASE
# =========================================================

if not os.path.exists(DATABASE):
    raise FileNotFoundError(
        f"MEDINTEL database not found:\n{DATABASE}"
    )

print("\nMEDINTEL DATABASE:")
print(DATABASE)


# =========================================================
# LOAD DATA FROM SQL
# =========================================================

connection = sqlite3.connect(DATABASE)

df = pd.read_sql_query(
    "SELECT * FROM pharmacy_sales",
    connection
)

connection.close()

print("\nDATA LOADED FROM SQL")
print("Dataset Shape:", df.shape)


if df.empty:
    raise ValueError(
        "No pharmacy data found in SQL database."
    )


# =========================================================
# DATE PROCESSING
# =========================================================

df["Date of Sale"] = pd.to_datetime(
    df["Date of Sale"],
    errors="coerce"
)

df = df.dropna(
    subset=["Date of Sale"]
)


# =========================================================
# CREATE DATE FEATURES
# =========================================================

df["Month"] = (
    df["Date of Sale"].dt.month
)

df["Day"] = (
    df["Date of Sale"].dt.day
)

df["Day_of_Week"] = (
    df["Date of Sale"].dt.dayofweek
)


# =========================================================
# SORT DATA
# =========================================================

df = df.sort_values(
    ["Medicine Name", "Date of Sale"]
)


# =========================================================
# PREVIOUS DEMAND
# =========================================================

df["Previous_Demand"] = (
    df.groupby("Medicine Name")["Quantity Sold"]
    .shift(1)
)


# =========================================================
# ROLLING AVERAGE DEMAND
# =========================================================

df["Rolling_Average_Demand"] = (
    df.groupby("Medicine Name")["Quantity Sold"]
    .transform(
        lambda x:
        x.shift(1).rolling(3).mean()
    )
)


# =========================================================
# REMOVE MISSING VALUES
# =========================================================

df = df.dropna(
    subset=[
        "Previous_Demand",
        "Rolling_Average_Demand"
    ]
)


print("\nML-READY DATA:")
print(df.shape)


# =========================================================
# FEATURES AND TARGET
# =========================================================

features = [
    "Selling Price",
    "Current Stock",
    "Month",
    "Day",
    "Day_of_Week",
    "Previous_Demand",
    "Rolling_Average_Demand"
]

X = df[features]

y = df["Quantity Sold"]


# =========================================================
# TIME-BASED TRAIN / TEST SPLIT
# =========================================================

split_index = int(
    len(df) * 0.8
)

X_train = X.iloc[:split_index]
X_test = X.iloc[split_index:]

y_train = y.iloc[:split_index]
y_test = y.iloc[split_index:]


print("\nTRAINING DATA:")
print(X_train.shape)

print("\nTESTING DATA:")
print(X_test.shape)


# =========================================================
# RANDOM FOREST MODEL
# =========================================================

model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

model.fit(
    X_train,
    y_train
)

print("\nMODEL TRAINING COMPLETED SUCCESSFULLY!")


# =========================================================
# PREDICTION
# =========================================================

y_pred = model.predict(
    X_test
)


# =========================================================
# MODEL EVALUATION
# =========================================================

mae = mean_absolute_error(
    y_test,
    y_pred
)

mse = mean_squared_error(
    y_test,
    y_pred
)

r2 = r2_score(
    y_test,
    y_pred
)


print("\n==============================")
print("MODEL EVALUATION")
print("==============================")

print(
    "Mean Absolute Error:",
    round(mae, 2)
)

print(
    "Mean Squared Error:",
    round(mse, 2)
)

print(
    "R2 Score:",
    round(r2, 2)
)


# =========================================================
# DECISION SUPPORT DATA
# =========================================================

decision_support = df.iloc[
    split_index:
].copy()

decision_support[
    "Predicted_Demand"
] = y_pred.round(2)


# =========================================================
# INVENTORY DECISION
# =========================================================

decision_support[
    "Inventory_Status"
] = decision_support.apply(
    lambda row:
        "Reorder Recommended"
        if row["Current Stock"]
        < row["Predicted_Demand"]
        else "Stock Sufficient",
    axis=1
)


# =========================================================
# DISPLAY DECISION SUPPORT
# =========================================================

print("\n==============================")
print("MEDINTEL DECISION SUPPORT")
print("==============================")

print(
    decision_support[
        [
            "Medicine Name",
            "Current Stock",
            "Predicted_Demand",
            "Inventory_Status"
        ]
    ].head(15)
)


# =========================================================
# SAVE OUTPUT
# =========================================================

output_columns = [
    "Medicine Name",
    "Date of Sale",
    "Current Stock",
    "Predicted_Demand",
    "Inventory_Status"
]

decision_support[
    output_columns
].to_csv(
    OUTPUT_FILE,
    index=False
)


print("\n==============================")
print("OUTPUT FILE SAVED")
print("==============================")

print(OUTPUT_FILE)

print(
    "\nMEDINTEL ML DEMAND PREDICTION COMPLETED SUCCESSFULLY!"
)