// =========================================================
// MEDINTEL — MAIN DASHBOARD SCRIPT
// =========================================================


// =========================================================
// OPEN DASHBOARD
// =========================================================

function openDashboard() {

    document.querySelector(".landing-page").style.display = "none";

    document.querySelector(".dashboard-page").style.display = "block";

    loadDashboardData();

    loadInventoryData();

}


// =========================================================
// DASHBOARD DATA
// =========================================================

function loadDashboardData() {

    fetch("http://127.0.0.1:5000/api/dashboard")

        .then(response => {

            if (!response.ok) {
                throw new Error("Dashboard API failed");
            }

            return response.json();

        })

        .then(data => {

            const kpiCards =
                document.querySelectorAll(".kpi-card strong");


            // TOTAL SALES

            if (kpiCards[0]) {

                kpiCards[0].textContent =
                    "₹" +
                    Number(data.total_sales)
                        .toLocaleString("en-IN");

            }


            // QUANTITY SOLD

            if (kpiCards[1]) {

                kpiCards[1].textContent =
                    Number(data.total_quantity)
                        .toLocaleString("en-IN");

            }


            // TOTAL MEDICINES

            if (kpiCards[2]) {

                kpiCards[2].textContent =
                    data.total_medicines;

            }


            // =================================================
            // TOP 10 FAST-MOVING MEDICINES
            // =================================================

            const medicineRows =
                document.querySelectorAll(".medicine-row");


            data.top_medicines.forEach((medicine, index) => {

                if (medicineRows[index]) {

                    const medicineName =
                        medicine["Medicine Name"];

                    const quantity =
                        medicine.quantity;

                    const number =
                        String(index + 1).padStart(2, "0");


                    medicineRows[index]
                        .querySelector("span")
                        .innerHTML =
                        "<i>" +
                        number +
                        "</i>" +
                        medicineName;


                    medicineRows[index]
                        .querySelector("b")
                        .textContent =
                        quantity;

                }

            });


            // =================================================
            // MONTHLY SALES REVENUE
            // =================================================

            const bars =
                document.querySelectorAll(
                    ".chart-placeholder .bar"
                );


            const monthlyData =
                data.monthly_sales;


            if (
                monthlyData &&
                monthlyData.length > 0
            ) {

                const maxRevenue =
                    Math.max(
                        ...monthlyData.map(
                            item => Number(item.revenue)
                        )
                    );


                monthlyData.forEach((item, index) => {

                    if (bars[index]) {

                        const revenue =
                            Number(item.revenue);


                        const height =
                            maxRevenue > 0
                                ? (revenue / maxRevenue) * 100
                                : 0;


                        bars[index].style.height =
                            height + "%";


                        const month =
                            item.month.substring(5);


                        const monthNames = {

                            "01": "Jan",
                            "02": "Feb",
                            "03": "Mar",
                            "04": "Apr",
                            "05": "May",
                            "06": "Jun",
                            "07": "Jul",
                            "08": "Aug",
                            "09": "Sep",
                            "10": "Oct",
                            "11": "Nov",
                            "12": "Dec"

                        };


                        bars[index].textContent =
                            monthNames[month] || month;

                    }

                });

            }

        })


        .catch(error => {

            console.error(
                "Dashboard API Error:",
                error
            );

        });

}


// =========================================================
// ML INVENTORY DATA
// =========================================================

function loadInventoryData() {

    fetch("http://127.0.0.1:5000/api/inventory")

        .then(response => {

            if (!response.ok) {
                throw new Error("Inventory API failed");
            }

            return response.json();

        })

        .then(data => {

            const kpiCards =
                document.querySelectorAll(".kpi-card strong");


            // REORDER ALERT KPI

            if (kpiCards[3]) {

                kpiCards[3].textContent =
                    data.reorder_recommended;

            }


            // INVENTORY CARDS

            const inventoryCards =
                document.querySelectorAll(".inventory-card");


            // REORDER RECOMMENDED

            if (inventoryCards[0]) {

                inventoryCards[0]
                    .querySelector("strong")
                    .textContent =
                    data.reorder_recommended +
                    " MEDICINES";

            }


            // STOCK SUFFICIENT

            if (inventoryCards[1]) {

                inventoryCards[1]
                    .querySelector("strong")
                    .textContent =
                    data.stock_sufficient +
                    " MEDICINES";

            }

        })


        .catch(error => {

            console.error(
                "Inventory API Error:",
                error
            );

        });

}


// =========================================================
// PHARMACY DATA UPLOAD
// =========================================================

function handleFileSelection() {

    const fileInput =
        document.getElementById("pharmacyFile");

    const message =
        document.getElementById("uploadMessage");


    if (!fileInput || !message) {

        console.error(
            "Pharmacy upload elements not found."
        );

        return;

    }


    const file =
        fileInput.files[0];


    // -----------------------------------------------------
    // NO FILE
    // -----------------------------------------------------

    if (!file) {

        message.textContent =
            "Please select a CSV or Excel file first.";

        message.style.color =
            "#df7777";

        return;

    }


    // -----------------------------------------------------
    // FILE TYPE
    // -----------------------------------------------------

    const allowedExtensions = [

        ".csv",
        ".xlsx",
        ".xls"

    ];


    const fileName =
        file.name.toLowerCase();


    const isValidExtension =
        allowedExtensions.some(
            extension =>
                fileName.endsWith(extension)
        );


    if (!isValidExtension) {

        message.textContent =
            "Invalid file format. Please select CSV or Excel.";

        message.style.color =
            "#df7777";

        fileInput.value = "";

        return;

    }


    // -----------------------------------------------------
    // FILE SIZE
    // -----------------------------------------------------

    const maxFileSize =
        10 * 1024 * 1024;


    if (file.size > maxFileSize) {

        message.textContent =
            "File is too large. Maximum allowed size is 10 MB.";

        message.style.color =
            "#df7777";

        fileInput.value = "";

        return;

    }


    // -----------------------------------------------------
    // ACTUAL UPLOAD
    // -----------------------------------------------------

    uploadPharmacyFile(file);

}


// =========================================================
// UPLOAD FILE TO FLASK
// =========================================================

function uploadPharmacyFile(file) {

    const message =
        document.getElementById("uploadMessage");


    if (!message) {
        return;
    }


    message.textContent =
        "Uploading pharmacy data...";

    message.style.color =
        "#52d6c2";


    const formData =
        new FormData();


    formData.append(
        "file",
        file
    );


    fetch(
        "http://127.0.0.1:5000/api/upload",
        {

            method: "POST",

            body: formData

        }
    )


        .then(response => {

            return response.json()
                .then(data => ({

                    ok: response.ok,

                    data: data

                }));

        })


        .then(result => {

            const data =
                result.data;


            if (!result.ok || !data.success) {

                message.textContent =
                    data.message ||
                    "Upload failed.";

                message.style.color =
                    "#df7777";

                return;

            }


            // -------------------------------------------------
            // SUCCESS
            // -------------------------------------------------

            message.textContent =
                "✓ " +
                data.message +
                " (" +
                data.rows_uploaded +
                " rows, " +
                data.medicines +
                " medicines)";


            message.style.color =
                "#52d6c2";


            console.log(
                "Pharmacy data uploaded successfully:",
                data
            );


            // -------------------------------------------------
            // REFRESH DASHBOARD
            // -------------------------------------------------

            loadDashboardData();

            loadInventoryData();

        })


        .catch(error => {

            console.error(
                "Upload Error:",
                error
            );


            message.textContent =
                "Unable to connect to MEDINTEL backend.";

            message.style.color =
                "#df7777";

        });

}


// =========================================================
// USE DEMO DATA
// =========================================================

function useDemoData() {

    const message =
        document.getElementById("uploadMessage");


    if (message) {

        message.textContent =
            "Demo pharmacy dataset selected.";

        message.style.color =
            "#52d6c2";

    }


    loadDashboardData();

    loadInventoryData();

}


// =========================================================
// FILE INPUT CHANGE
// =========================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const fileInput =
            document.getElementById("pharmacyFile");


        if (fileInput) {

            fileInput.addEventListener(
                "change",
                handleFileSelection
            );

        }

    }
);