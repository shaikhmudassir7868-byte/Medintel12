from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import pandas as pd
import os

# =========================================================
# MEDINTEL BACKEND
# =========================================================

app = Flask(__name__)
CORS(app)

# =========================================================
# PROJECT PATHS
# =========================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATABASE = os.path.join(
    BASE_DIR,
    "medintel.db"
)

ML_FILE = os.path.join(
    BASE_DIR,
    "01_data",
    "MEDINTEL_ML_Decision_Support.csv"
)

# =========================================================
# REQUIRED COLUMNS
# =========================================================

REQUIRED_COLUMNS = [
    "Medicine Name",
    "Date of Sale",
    "Quantity Sold",
    "Selling Price",
    "Total Sale Value",
    "Current Stock",
    "Category",
    "Expiry Date",
    "Supplier"
]


# =========================================================
# DATABASE CONNECTION
# =========================================================

def get_database_connection():

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    return connection


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():

    return "MEDINTEL Backend is running!"


# =========================================================
# DASHBOARD API
# =========================================================

@app.route("/api/dashboard")
def dashboard():

    connection = get_database_connection()

    total_sales = connection.execute(
        """
        SELECT SUM("Total Sale Value") AS total
        FROM pharmacy_sales
        """
    ).fetchone()["total"]

    total_quantity = connection.execute(
        """
        SELECT SUM("Quantity Sold") AS total
        FROM pharmacy_sales
        """
    ).fetchone()["total"]

    total_medicines = connection.execute(
        """
        SELECT COUNT(DISTINCT "Medicine Name") AS total
        FROM pharmacy_sales
        """
    ).fetchone()["total"]

    top_medicines = connection.execute(
        """
        SELECT
            "Medicine Name",
            SUM("Quantity Sold") AS quantity
        FROM pharmacy_sales
        GROUP BY "Medicine Name"
        ORDER BY quantity DESC
        LIMIT 10
        """
    ).fetchall()

    monthly_sales = connection.execute(
        """
        SELECT
            substr("Date of Sale", 1, 7) AS month,
            SUM("Total Sale Value") AS revenue
        FROM pharmacy_sales
        GROUP BY month
        ORDER BY month
        """
    ).fetchall()

    connection.close()

    return jsonify({

        "total_sales": total_sales or 0,

        "total_quantity": total_quantity or 0,

        "total_medicines": total_medicines or 0,

        "top_medicines": [
            dict(row)
            for row in top_medicines
        ],

        "monthly_sales": [
            dict(row)
            for row in monthly_sales
        ]

    })


# =========================================================
# INVENTORY API
# =========================================================

@app.route("/api/inventory")
def inventory():

    if not os.path.exists(ML_FILE):

        return jsonify({

            "reorder_recommended": 0,

            "stock_sufficient": 0,

            "message":
                "ML decision support file not found."

        })

    try:

        df = pd.read_csv(
            ML_FILE
        )

        if "Inventory_Status" not in df.columns:

            return jsonify({

                "error":
                    "Inventory status column not found."

            }), 500

        reorder_count = int(
            (
                df["Inventory_Status"]
                == "Reorder Recommended"
            ).sum()
        )

        sufficient_count = int(
            (
                df["Inventory_Status"]
                == "Stock Sufficient"
            ).sum()
        )

        return jsonify({

            "reorder_recommended":
                reorder_count,

            "stock_sufficient":
                sufficient_count

        })

    except Exception as error:

        return jsonify({

            "error": str(error)

        }), 500


# =========================================================
# PHARMACY DATA UPLOAD
# =========================================================

@app.route(
    "/api/upload",
    methods=["POST"]
)
def upload_pharmacy_data():

    if "file" not in request.files:

        return jsonify({

            "success": False,

            "message":
                "No file uploaded."

        }), 400

    file = request.files["file"]

    if file.filename == "":

        return jsonify({

            "success": False,

            "message":
                "No file selected."

        }), 400

    filename = file.filename.lower()

    try:

        # =================================================
        # READ CSV / EXCEL
        # =================================================

        if filename.endswith(".csv"):

            df = pd.read_csv(
                file
            )

        elif filename.endswith(
            (".xlsx", ".xls")
        ):

            df = pd.read_excel(
                file
            )

        else:

            return jsonify({

                "success": False,

                "message":
                    "Only CSV and Excel files are supported."

            }), 400


        # =================================================
        # CLEAN COLUMN NAMES
        # =================================================

        df.columns = [
            str(column).strip()
            for column in df.columns
        ]


        # =================================================
        # VALIDATE COLUMNS
        # =================================================

        missing_columns = [

            column

            for column in REQUIRED_COLUMNS

            if column not in df.columns

        ]

        if missing_columns:

            return jsonify({

                "success": False,

                "message":
                    "Required columns are missing.",

                "missing_columns":
                    missing_columns

            }), 400


        # =================================================
        # REMOVE COMPLETELY EMPTY ROWS
        # =================================================

        df = df.dropna(
            how="all"
        )


        # =================================================
        # NUMERIC VALIDATION
        # =================================================

        numeric_columns = [

            "Quantity Sold",

            "Selling Price",

            "Total Sale Value",

            "Current Stock"

        ]

        for column in numeric_columns:

            df[column] = pd.to_numeric(
                df[column],
                errors="coerce"
            )


        # =================================================
        # DATE VALIDATION
        # =================================================

        df["Date of Sale"] = pd.to_datetime(
            df["Date of Sale"],
            errors="coerce"
        )

        df["Expiry Date"] = pd.to_datetime(
            df["Expiry Date"],
            errors="coerce"
        )


        # =================================================
        # REMOVE INVALID ROWS
        # =================================================

        df = df.dropna(
            subset=[
                "Medicine Name",
                "Date of Sale",
                "Quantity Sold",
                "Selling Price",
                "Current Stock"
            ]
        )


        if df.empty:

            return jsonify({

                "success": False,

                "message":
                    "No valid pharmacy records found."

            }), 400


        # =================================================
        # CONVERT DATES TO SQL-FRIENDLY FORMAT
        # =================================================

        df["Date of Sale"] = (
            df["Date of Sale"]
            .dt.strftime("%Y-%m-%d")
        )

        df["Expiry Date"] = (
            df["Expiry Date"]
            .dt.strftime("%Y-%m-%d")
        )


        # =================================================
        # SAVE TO SQLITE
        # =================================================

        connection = sqlite3.connect(
            DATABASE
        )

        df.to_sql(
            "pharmacy_sales",
            connection,
            if_exists="replace",
            index=False
        )

        connection.close()


        # =================================================
        # RESPONSE
        # =================================================

        rows_uploaded = len(df)

        medicines = (
            df["Medicine Name"]
            .nunique()
        )

        return jsonify({

            "success": True,

            "message":
                "Pharmacy data uploaded successfully.",

            "filename":
                file.filename,

            "rows_uploaded":
                rows_uploaded,

            "medicines":
                medicines

        })


    except Exception as error:

        return jsonify({

            "success": False,

            "message":
                str(error)

        }), 500


# =========================================================
# RUN SERVER
# =========================================================

if __name__ == "__main__":

    print(
        "\nMEDINTEL BACKEND STARTING..."
    )

    print(
        "Database:",
        DATABASE
    )

    print(
        "ML File:",
        ML_FILE
    )

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )